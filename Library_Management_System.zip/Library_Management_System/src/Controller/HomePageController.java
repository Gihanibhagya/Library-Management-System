// File: Controller/HomePageController.java
package Controller;

import View.Home_Page;
import View.*;
import static com.sun.glass.ui.Cursor.setVisible;


public class HomePageController {
    private final Home_Page homePageView;

    public HomePageController(Home_Page homePageView) {
        this.homePageView = homePageView;
    }
        private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        setVisible(false);
        new StudentDetails().setVisible(true);
    }                                        

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        setVisible(false);
        new Return_Book().setVisible(true);
        
    }                                        

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        setVisible(false);
        new login_page().setVisible(true);
    }                                        

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
       setVisible(false);
        new New_Student().setVisible(true);
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
       setVisible(false);
        new New_Book().setVisible(true);
    }                                        

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        setVisible(false);
        new Issue_Book().setVisible(true);
    }                                   
    public void showHomePage() {
        homePageView.setVisible(true);
    }
}
