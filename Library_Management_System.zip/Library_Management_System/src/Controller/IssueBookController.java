package Controller;

import Model.IssueModel;
import View.ConnectionProvider;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class IssueBookController {

    public static boolean issueBook(String bookID, String studentID, String issueDate, String dueDate) {
        String returnBook = "No";
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM book WHERE bookID = ?");
            ps.setString(1, bookID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PreparedStatement ps1 = con.prepareStatement("SELECT * FROM student WHERE studentID = ?");
                ps1.setString(1, studentID);
                ResultSet rs1 = ps1.executeQuery();

                if (rs1.next()) {
                    PreparedStatement ps2 = con.prepareStatement("INSERT INTO issue VALUES (?, ?, ?, ?, ?)");
                    ps2.setString(1, bookID);
                    ps2.setString(2, studentID);
                    ps2.setString(3, issueDate);
                    ps2.setString(4, dueDate);
                    ps2.setString(5, returnBook);

                    ps2.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Book successfully issued");
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect studentID");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect BookID");
            }
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Connection Error: " + e);
        }
        return false;
    }
}
