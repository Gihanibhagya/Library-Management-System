package View;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {
    public static Connection getCon() throws SQLException {
        // Establish connection to your database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database_name", "username", "password");
        return con;
    }
}
