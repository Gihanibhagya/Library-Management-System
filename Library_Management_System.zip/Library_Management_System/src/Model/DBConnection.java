package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author HP
 */
public class DBConnection {

    static Connection conn;
    static Statement stat = null;

    public static Statement getStatementConnection() {
        try {
            // Establish the connection
            String url = "jdbc:mysql://localhost:3306/Library_Management_System";
            conn = DriverManager.getConnection(url, "root", "");
            // Create the statement
            stat = conn.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stat;
    }

    /**
     *
     * @throws SQLException
     */
    public static void closeCon() throws SQLException {
        if (stat != null) {
            stat.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    public static void StudentDetails() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
