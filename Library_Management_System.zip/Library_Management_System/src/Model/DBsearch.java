package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBsearch {
    private Statement stmt;
    private ResultSet rs;

    public ResultSet searchUser(String UserName) {
        try {
            stmt = DBConnection.getStatementConnection();
            String name = UserName;

            try {
                // Execute the Query
                rs = stmt.executeQuery("SELECT * FROM user WHERE Username='" + name + "'");
            } catch (SQLException ex) {
                Logger.getLogger(DBsearch.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rs;
    }

    public ResultSet searchOrder() {
        try {
            stmt = DBConnection.getStatementConnection();

            try {
                rs = stmt.executeQuery("SELECT * FROM order_items");
            } catch (SQLException ex) {
                Logger.getLogger(DBsearch.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rs;
    }
}
