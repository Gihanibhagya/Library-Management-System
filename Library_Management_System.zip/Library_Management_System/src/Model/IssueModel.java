package Model;

import View.ConnectionProvider;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class IssueModel {
    public boolean issueBook(String bookID, String studentID, String issueDate, String dueDate, String returnBook) {
        try {
            Connection con = ConnectionProvider.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from book where bookID='" + bookID + "'");
            if (rs.next()) {
                ResultSet rsl = st.executeQuery("select * from student where studentID='" + studentID + "'");
                if (rsl.next()) {
                    st.executeUpdate("insert into issue values('" + bookID + "','" + studentID + "','" + issueDate + "','" + dueDate + "','" + returnBook + "')");
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
