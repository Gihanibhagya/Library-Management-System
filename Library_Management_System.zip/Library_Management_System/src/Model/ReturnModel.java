package Model;

import View.ConnectionProvider;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReturnModel {
    public ResultSet searchIssue(String bookID, String studentID) throws SQLException {
        Connection con = ConnectionProvider.getCon();
        Statement st = con.createStatement();
        return st.executeQuery("select * from issue where bookID='" + bookID + "' and studentID='" + studentID + "'");
    }

    public void returnBook(String bookID, String studentID) throws SQLException {
        Connection con = ConnectionProvider.getCon();
        Statement st = con.createStatement();
        st.executeUpdate("update issue set returnBook='YES' where studentID='" + studentID + "' and bookID='" + bookID + "'");
    }
}
